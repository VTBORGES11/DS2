class DDD:
    def __init__(self, codigo, cidade) -> None:
        self.codigo = codigo
        self.cidade = cidade