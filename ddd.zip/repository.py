from main import DDD
codigos = [
    {"codigo": 11, "cidade": "São Paulo"},
    {"codigo": 19, "cidade": "Campinas"},
    {"codigo": 21, "cidade": "Rio de Janeiro"},
    {"codigo": 27, "cidade": "Vitoria"},
    {"codigo": 31, "cidade": "Belo Horizonte"},
    {"codigo": 32, "cidade": "Juiz de Fora"},
    {"codigo": 61, "cidade": "Brasília"},
    {"codigo": 71, "cidade": "Salvador"}
]